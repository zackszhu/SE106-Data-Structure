#include <vector>
#include <iostream>
#include <fstream>
using namespace std;

const int MAXINT = (unsigned int)~0 >> 1;

int main(int argc, char** argv) {
	ifstream infile;
	infile.open(argv[1]);
	int n, m;
	infile >> n;
	vector< vector<int> > map(n + 1, vector<int>(n + 1, MAXINT));
	infile >> m;
	for (auto i = 0; i < m; i++) {
		int x, y;
		infile >> x >> y;
		infile >> map[x][y];
	}
	vector<int> dist(n + 1, MAXINT);
	for (auto i = 0; i <= n; i++)
		dist[i] = map[0][i];
	vector<bool> used(n + 1, false);
	used[0] = true;
	dist[0] = 0;
	for (auto i = 0; i <= n; i++) {
		int tmin = MAXINT;
		int k = 0;
		for (auto j = 0; j <= n; j++) {
			if (!used[j] && tmin > dist[j]) {
				tmin = dist[j];
				k = j;
			}
		}
		used[k] = true;
		for (auto j = 0; j <= n; j++) {
			dist[j] = dist[j] > (unsigned int)(dist[k] + map[k][j]) ? dist[k] + map[k][j] : dist[j];
		}
	}
	for (auto i = 0; i <= n; i++) 
		cout << (dist[i] == MAXINT ? -1 : dist[i])  << " ";
}